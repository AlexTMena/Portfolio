<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Blue
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

    <!-- Main content -->
        
        <!-- Jumbotron section -->
        <div id="carouselWrapper" class="container-fluid">
            <div id="slides" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#slides" data-slide-to="0" class="active"></li>
                    <li data-target="#slides" data-slide-to="1"></li>
                    <li data-target="#slides" data-slide-to="2"></li>
                </ul>
                <div class="carousel-inner container">
                    <div class="carousel-item active">
                        <img src="<?php echo(get_template_directory_uri()); ?>/img/slide-1.jpg" class="img-fluid">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo(get_template_directory_uri()); ?>/img/slide-2.jpg" class="img-fluid">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo(get_template_directory_uri()); ?>/img/slide-3.jpg" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>

        <!-- Portfolio Section -->

        <div id="modal" class="d-none">
            <div id="modal-content" class="row">
                <img class="img-fluid col" id="modalImgContainer" src="psd resources/Blue Theme.jpg">
                <span onclick="closeModal()" class="close-modal">&times;</span>
            </div>
        </div>

        <div id="aboutMe" class="container">
            <div class="container">
                    <h1>Hi! I’m Alexandro Meña.</h1>
                    <p>I’m a front-end web developer.</p>
                    <p>I specialize in developing a responsive website from scratch.</p>
                    <p>Goal oriented, works smart, team-player and a self-starter.</p>
                    <p class="skillList">Expert in:
                        <ul>
                            <li>HTML</li>
                            <li>CSS</li>
                            <li>Bootstrap 4</li>
                            <li>Javascript</li>
                        </ul>
                    </p>
                </div>
        </div>

        <div id="portfolio" class="container">
            <div class="content-wrapper">
                <h3 class="text-center">Here are some of my works:</h3>
                <div id="psd-to-html">
                    <h4 class="text-lg-left text-center">Psd to HTML</h4>
                    <div class="psd-to-html-portfolio row text-center">
                        <?php  /* Start the Loop */ ?>
                            <?php $myquery = new WP_Query('category_name=PSD to HTML&posts_per_page=4'); ?>
                            <?php while ( $myquery->have_posts() ) : $myquery->the_post(); ?>

                            <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                                <div class="entry">
                                    <a href="<?php the_permalink() ?>">
                                        <div class="thumbnail">
                                            <?php the_post_thumbnail(); ?>
                                        </div>
                                        <p><?php the_title(); ?></p>
                                        <h6>Posted by: <?php the_author(); ?></h6>
                                    </a>
                                    <p><?php the_excerpt(); ?></p>
                                </div>
                            </div>                       
                        <?php endwhile; ?>
                    </div>
                    
                    
                    <!-- <div class="psd-to-html-portfolio row text-center">
                        <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(0,0)" class="img-fluid psdToHtml" src="img/portfolio-sample-1.jpg">
                            <p>My Website</p>
                        </div>
                        <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(0,1)" class="img-fluid psdToHtml" src="img/portfolio-sample-1.jpg">
                            <p>My Website</p>
                        </div>
                        <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(0,2)" class="img-fluid psdToHtml" src="img/portfolio-sample-1.jpg">
                            <p>My Website</p>
                        </div>
                        <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(0,3)" class="img-fluid psdToHtml" src="img/portfolio-sample-1.jpg">
                            <p>My Website</p>
                        </div>
                    </div> -->
                </div>
                <div id="js-application">
                    <h4 class="text-lg-left text-center">Javascript Application</h4>
                    <div class="javascript-application-portfolio row text-center">
                        
                    <?php  /* Start the Loop */ ?>
                            <?php $myquery2 = new WP_Query('category_name=JavaScript Application&posts_per_page=4'); ?>
                            <?php while ( $myquery2->have_posts() ) : $myquery2->the_post(); ?>

                            <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                                <div class="entry">
                                    <a href="<?php the_permalink() ?>">
                                        <div class="thumbnail">
                                            <?php the_post_thumbnail(); ?>
                                        </div>
                                        <p><?php the_title(); ?></p>
                                        <h6>Posted by: <?php the_author(); ?></h6>
                                    </a>
                                    <p><?php the_excerpt(); ?></p>
                                </div>
                            </div>                       
                        <?php endwhile; ?>

                        <!-- <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(1,0)" class="js-app" src="img/portfolio-sample-1.jpg">
                            <p>JS App #1</p>
                        </div>
                        <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(1,1)" class="js-app" src="img/portfolio-sample-1.jpg">
                            <p>JS App #2</p>
                        </div>
                        <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(1,2)" class="js-app" src="img/portfolio-sample-1.jpg">
                            <p>JS App #3</p>
                        </div>
                        <div class="portfolio-entry col-lg-3 col-md-6 col-sm-12">
                            <img onclick="openModal(1,3)" class="js-app" src="img/portfolio-sample-1.jpg">
                            <p>JS App #4</p>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact section -->

        <div id="contact-section" class="container">
            <div class="row">
                <h4 class="col-12 text-center">Contact me here:</h4>
                <div id="contact-form" class="col-lg-6 text-center">
                    
                    <a href="http://localhost/contact-me/">
                    <button id="contactme" class=" btn primary">
                        Leave a message
                    </button>
                    </a>
                    <!-- <form>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-md-2 col-form-label">Email</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="staticEmail" value="email@email.com">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputTitle" class="col-md-2 col-form-label">Title</label>
                            <div class="col-md-10">
                                <input type="text" class="form-control" id="inputTitle" placeholder="Title">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputMessage" class="col-md-2 col-form-label">Message</label>
                            <div class="col-md-10">
                                <textarea class="form-control" id="inputMessage" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn">Submit</button>
                        </div>
                    </form> -->
                </div>
                <div id="contact-details" class="col-lg-6 text-center">              
                    <h5>Contact number:</h5>
                    <p>0933-569-8495</p>
                    <h5>E-mail Address:</h5>
                    <p>alexandro.mena0108@gmail.com</p>
                    <h5>Facebook:</h5>
                    <p>https://www.facebook.com/atmena0108</p>
                </div>
            </div>
        </div>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
